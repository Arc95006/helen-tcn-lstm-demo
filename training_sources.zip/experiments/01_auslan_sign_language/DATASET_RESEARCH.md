# Dataset and implementation research — 8 October 2026

## Selected and actually run

**UCI Australian Sign Language Signs, dataset 114**

- Official page: https://archive.ics.uci.edu/dataset/114/australian+sign+language+signs
- Download: https://archive.ics.uci.edu/static/public/114/australian+sign+language+signs.zip
- Real PowerGlove recordings with sign labels and signer/session identifiers. UCI describes 95 signs, 6,650 sign samples, five signers, and a 2.9 MB archive.
- The local archive also contains calibration signs. We select only ten named vocabulary signs and obtain 699 real recordings. We exclude calibration files and non-sign content.
- Eight informative channels: x/y/z/roll, thumb/fore/middle/ring finger bend. Missing pitch/yaw, duplicate little-finger bend, control codes and receiver flags are excluded.
- Advantage for today's demo: small, no login, already numerical temporal sequences, genuine signer holdout, no video feature-extraction stage.
- Limitation: Auslan, not ISL; glove sensors, not camera landmarks. This experiment validates comparison machinery and sign-sequence classification, not the wearable or camera pipeline.
- UCI currently lists CC BY 4.0. Original archive documentation contains older donor conditions, including acknowledgement and a request to inform the donor upon publication. Preserve both documents and check applicable conditions before publishing or commercial use. No messages have been sent to the donor.
- Citation: M. Kadous, “Australian Sign Language Signs,” UCI Machine Learning Repository, 1995, doi: 10.24432/C5XG6C.

## Other real datasets checked

**Kaggle Google Isolated Sign Language Recognition**

https://www.kaggle.com/competitions/asl-signs/data

Real ASL video-derived MediaPipe landmark sequences and participant identifiers. The data page lists 56.43 GB and access requiring login and agreement to competition rules. Its feature modality is closer to the future webcam pipeline, but the download/access burden makes it less convenient today. We did not download it or accept its rules.

**AI4Bharat INCLUDE**

https://github.com/AI4Bharat/sign-language.ai4bharat.org/blob/master/docs/INCLUDE.md

An ISL dataset worth considering for the final project. Video-based data requires download/access checks and landmark extraction. We have not trained on INCLUDE or verified every video download.

**UCI Australian Sign Language Signs (High Quality), dataset 115**

https://www.archive.ics.uci.edu/dataset/115/australian%2Bsign%2Blanguage%2Bsigns%2Bhigh%2Bquality

The page describes 2,565 sequences, 95 signs, 22 channels and one native signer across nine weeks. Its current file listing shows the main archives as only 51/52 bytes, so we chose the available dataset 114 archive instead. The high-quality listing was inspected, but its data were not used in our experiment.

## Existing code and research

**Authors' TCN implementation and benchmark code**

https://github.com/locuslab/TCN

https://arxiv.org/abs/1803.01271

The repository accompanies Bai, Kolter and Koltun's empirical comparison of convolutional and recurrent sequence models. It is a strong architecture/research reference. It is not a ready-made reproduction of our Auslan signer split. Our compact implementation follows the causal/dilated/residual TCN design and uses PyTorch's LSTM; we have not copied a project's reported numbers.

**tsai — time-series model library with both LSTM and TCN**

https://github.com/timeseriesAI/tsai

Includes both architectures in a common training ecosystem, useful for broader future comparisons. We inspected its documented model list rather than installing another training stack today. Our current project already runs the required paired experiment with fewer dependencies.

This comparison is a fixed configuration and one seed, with unequal parameter counts. It is sufficient for weekly progress, but repeated signer splits and validation-based hyperparameter selection are needed for final research conclusions.
