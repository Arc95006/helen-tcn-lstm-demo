"""Download and prepare UCI Auslan sensor sequences without extracting archive paths."""
from collections import Counter
import hashlib
import io
import json
from pathlib import PurePosixPath
import re
import tarfile
import urllib.request
import zipfile

import numpy as np
from demo import ROOT, FRAMES

URL = 'https://archive.ics.uci.edu/static/public/114/australian+sign+language+signs.zip'
LABELS = ['deaf', 'drink', 'eat', 'happy', 'hear', 'hello', 'no', 'sad', 'thank', 'yes']
CHANNELS = [0, 1, 2, 3, 6, 7, 8, 9]


def main():
    archive = ROOT / 'data' / 'downloads' / 'auslan.zip'
    archive.parent.mkdir(parents=True, exist_ok=True)
    if not archive.exists():
        urllib.request.urlretrieve(URL, archive)
    folder = ROOT / 'data' / 'auslan10'
    folder.mkdir(parents=True, exist_ok=True)
    counts, manifest = Counter(), []
    with zipfile.ZipFile(archive) as z:
        # Preserve the donor's documentation for attribution and data interpretation.
        (archive.parent / 'auslan_original_documentation.html').write_bytes(z.read('auslan.data.html'))
        with tarfile.open(fileobj=io.BytesIO(z.read('allsigns.tar.gz')), mode='r:gz') as tar:
            for member in tar.getmembers():
                if not member.isfile() or not member.name.endswith('.sign'):
                    continue
                parts = PurePosixPath(member.name).parts
                label = re.sub(r'\d+$', '', PurePosixPath(member.name).stem)
                if label not in LABELS:
                    continue
                session = parts[-2]
                signer = re.sub(r'\d+$', '', session)
                if signer not in ['adam', 'andrew', 'john', 'stephen', 'waleed']:
                    raise ValueError(f'Unknown signer: {member.name}')
                text = tar.extractfile(member).read().decode('ascii')
                rows = [[float(v.strip()) for v in line.split(',')[:11]] for line in text.splitlines() if line.strip()]
                raw = np.asarray(rows, dtype=np.float32)[:, CHANNELS]
                if not len(raw) or not np.isfinite(raw).all():
                    raise ValueError(f'Invalid sensor recording: {member.name}')
                old = np.linspace(0, 1, len(raw))
                new = np.linspace(0, 1, FRAMES)
                x = np.stack([np.interp(new, old, raw[:, c]) for c in range(len(CHANNELS))], axis=1).astype(np.float32)
                key = hashlib.sha256(member.name.encode()).hexdigest()[:16] + '.npz'
                np.savez_compressed(folder / key, x=x, label=label, session=signer)
                counts[(signer, label)] += 1
                manifest.append({'file': key, 'archive_path': member.name, 'label': label,
                                 'signer': signer, 'recording_session': session, 'original_frames': len(raw)})
    metadata = {
        'display_name': 'Real Australian Sign Language — 10-word sensor benchmark',
        'banner': 'REAL AUSLAN SENSOR DATA — benchmark demonstration; not ISL or live webcam recognition.',
        'source_url': 'https://archive.ics.uci.edu/dataset/114/australian+sign+language+signs',
        'download_url': URL, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'citation': 'M. Kadous, Australian Sign Language Signs, UCI, 1995, doi:10.24432/C5XG6C',
        'license_note': 'UCI lists CC BY 4.0. Original donor documentation is preserved under data/downloads.',
        'evaluation_note': 'Signer-disjoint split: all recordings of a person stay in one partition. One held-out test signer; one validation signer. A single small split is not a general language-recognition benchmark.',
        'labels': LABELS, 'channels': ['x', 'y', 'z', 'roll', 'thumb', 'forefinger', 'middle_finger', 'ring_finger'],
        'frames': FRAMES, 'preprocessing': 'Linear resampling of each complete recording to 30 steps, eight informative sensor channels. No filtering or augmentation. Pitch/yaw, duplicate little finger, control fields and receiver flags excluded. Linear interpolation of roll does not correct circular wraparound.',
        'sample_count': len(manifest), 'signer_counts': dict(Counter(m['signer'] for m in manifest)),
        'clip_manifest': manifest,
    }
    assert len(manifest) >= 600, f'Unexpectedly small subset: {len(manifest)}'
    assert all(counts[(person, word)] > 0 for person in metadata['signer_counts'] for word in LABELS)
    (folder / 'metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    print(f'Prepared {len(manifest)} real recordings, {len(LABELS)} signs, 5 signers, {FRAMES} frames x 8 channels.')
    print(metadata['signer_counts'])
    print('Per-word counts:', dict(Counter(m['label'] for m in manifest)))


if __name__ == '__main__':
    main()
