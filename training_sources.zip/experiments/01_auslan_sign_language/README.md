# TCN vs LSTM for isolated Indian Sign Language recognition

This experiment now lives in `01_auslan_sign_language`. Run the commands below from this folder; its Python environment, data, source files and results moved together.

Today's recommended deliverable is a working **model-comparison pipeline trained on real Australian Sign Language sensor recordings**. No real ISL dataset has been collected yet. The earlier synthetic demo remains available as a smoke test.

## Run the real-data demo

```powershell
powershell -ExecutionPolicy Bypass -File .\run_real_demo.ps1
```

The UCI dataset is downloaded and prepared locally. The script reuses the download, prepares the same 10-word subset, trains both models for 100 epochs, verifies saved predictions, and opens `runs/auslan10/report.html`. After the first download, this experiment runs offline. Dependencies and data must be installed/downloaded beforehand.

The real report includes measured learning curves, confusion matrices and a selector for 20 held-out recordings. It shows each actual label, both predictions, uncalibrated softmax confidence and recorded x/y/z sensor traces. The sample list is deterministic and includes mistakes. Glove traces are not video or anatomical animations.

The subset contains **699 recordings, 10 words and 5 signers**, with eight informative PowerGlove channels resampled to 30 timesteps. One expected `happy` recording is absent from the archive. The split for seed 42 is 460 training clips (john/waleed/adam), 80 validation clips (andrew), and 159 test clips (stephen). Every signer's sessions stay together. Validation loss chooses checkpoints; the test set does not select hyperparameters.

Measured first run:

| Model | Test accuracy | Macro F1 | Parameters | Train time | CPU median model latency |
| --- | ---: | ---: | ---: | ---: | ---: |
| TCN | 30.19% | 0.2397 | 23,146 | 23.58 s | 0.876 ms |
| LSTM | 49.69% | 0.4898 | 19,594 | 7.10 s | 0.201 ms |

LSTM performed better in this fixed-configuration experiment. Do not tune against these test results or claim general superiority. Sensor noise, limited data and signer differences are potential factors, not established causal explanations. Training times and latency depend on the computer. The 10-class chance baseline is approximately 10%.

Both real-data models are genuine sequence classifiers; the input layer is eight features instead of the webcam's 128. The future ISL webcam pipeline needs its own training data and weights. A sensor-trained model cannot accept camera landmarks directly.

See `PRESENTATION_NOTES.md` for PPT-specific weekly-progress wording and `DATASET_RESEARCH.md` for checked dataset/repository links. `data/auslan10/metadata.json` contains raw archive provenance and checksum. Per-class precision/recall/F1 are in `runs/auslan10/class_metrics.csv`. Macro precision/recall are in `results.json`.

Verification:

```powershell
.\.venv\Scripts\python.exe inspect_real_results.py
.\.venv\Scripts\python.exe verify_pipeline.py
```

These check disjoint groups/clips, raw recording provenance, training-only normalization, checkpoint accuracy/F1/confusion matrices and TCN causality.

## Run the earlier synthetic demo

Open PowerShell in this folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_demo.ps1
```

This trains real PyTorch TCN and LSTM classifiers and opens a local results report. No webcam is needed. The environment has been installed in `.venv`. Individual commands:

```powershell
.\.venv\Scripts\python.exe demo.py synthetic
.\.venv\Scripts\python.exe demo.py train --dataset synthetic --epochs 40
Start-Process .\runs\synthetic\report.html
```

`synthetic` adds clips; do not repeatedly run it unless you want more samples. `run_demo.ps1` reuses existing synthetic data. The synthetic dataset uses wave, ramp and pulse trajectories in a 30-frame, 128-feature tensor. It tests data loading, learning, checkpoint selection, evaluation and reporting. These tensors are not anatomical landmarks or actual signs.

## What is implemented

- Causal residual TCN: four blocks, dilations 1/2/4/8, two kernel-3 convolutions per block, 32 channels. Receptive field = 61 frames; classification reads the final timestep.
- LSTM: one recurrent layer with 64 hidden units; classification reads the final hidden state.
- Both receive identical clips and training-only standardization. Both use Adam, learning rate 0.001, batch size 16 and the same epoch budget. Best validation-loss checkpoint is evaluated once on test clips.
- Entire sessions are held out. No overlapping windows are split between train and test. With three sessions, one is train, one validation, one test. With more sessions, all remaining groups are train.
- Accuracy, macro F1, confusion matrices, parameter counts, training time and CPU batch-1 latency (median/P95). Latency excludes video capture and landmark extraction.
- JSON metrics, CSV comparison, exact split manifest, model checkpoints and HTML report under `runs/<dataset>/`.
- Future webcam collection and prompted two-second recognition with both trained models.

This is one fixed-configuration comparison, not equal parameter counts or a hyperparameter search. Repeat across several seeds and signer splits before claiming an architecture wins. Confidence is an uncalibrated softmax score; the threshold does not guarantee rejection of unseen signs.

## Collect the real dataset later

Choose 3–5 isolated words whose signs have been verified using the ISLRTC dictionary or a fluent ISL signer. Arbitrary gestures must be called a gesture dataset, not ISL. Ask your friends for consent to record them for the project. The current collector saves landmark sequences, not video or audio.

Recommended first dataset: 10 friends × 5 signs × 10 repetitions = 500 clips. Include variation in clothing, backgrounds and signing speed; keep hands visible and clip length consistent. For this prototype, use a **person ID as the session ID**, e.g. `friend01`, and keep that ID for all that person's recordings. This makes the held-out groups different people. Do not place the same person under several IDs across splits.

Download Google's hand landmark model once:

```powershell
.\.venv\Scripts\python.exe demo.py download-model
```

For each person and sign (replace `verified_word` with the actual label):

```powershell
.\.venv\Scripts\python.exe demo.py collect --label verified_word --session friend01 --clips 10
```

Press SPACE when ready to perform one isolated sign. The app samples 30 frames at roughly 15 samples/second; processing can extend capture duration on slow hardware. Press Q to quit. Every person/session must contain every label. Repeat all words for every friend. Handedness slots must stay consistent; the camera is unmirrored in both collection and inference.

Then:

```powershell
.\.venv\Scripts\python.exe demo.py train --dataset recorded --epochs 60
.\.venv\Scripts\python.exe demo.py live --dataset recorded
```

Live mode is a **prompted isolated-sign demo**: press SPACE to classify a complete clip, then read both predictions. It is not continuous signing or sentence translation. It refuses to use synthetic models on real webcam signs. No camera is opened by the synthetic demo. Camera workflows require local hardware verification before presentation.

The hand feature vector has two fixed left/right slots with 21 × 3 coordinates each and two presence indicators, totaling 128 features. Missing hands are zero-filled. Global hand coordinates retain movement but can be sensitive to camera placement. Face, body and mouth features are absent; these can matter for ISL. Add pose/face features and a larger verified dataset in later work.

## Weekly-progress presentation flow

1. **Problem:** explore recognition of a small vocabulary of isolated ISL signs to support communication.
2. **Research question:** how do TCN and LSTM compare using identical landmark sequences and evaluation splits?
3. **Pipeline:** camera → hand landmarks → 30-frame sequence → TCN/LSTM → word label. Today's run substitutes synthetic sequences at the feature-input stage.
4. **Completed this week:** architectures, training, session holdout, evaluation and report generation.
5. **Demo:** run the script, show training logs, then the measured report and confusion matrices.
6. **Next:** collect verified ISL recordings from 10 participants, train on held-out signers, repeat comparisons and test webcam inference.

Suggested wording: “We have implemented both sequence models and verified the training and evaluation pipeline using synthetic temporal data. Real ISL collection is the next stage. Today's accuracy numbers are pipeline-test results, not language-recognition results.”

Suggested title: **A Comparative Study of TCN and LSTM for Isolated Indian Sign Language Recognition**.

Do not claim bidirectional translation: sign-to-label, text-to-speech and speech-to-sign are separate components. This prototype implements sequence-to-label only. Text-to-speech can be added after real recognition works; speech-to-ISL needs a separate design.

## Setup on another computer

Install Python 3.12, then:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

`environment-lock.txt` records the versions used locally. If a camera cannot open, close other camera apps or try `--camera 1`.

## References

- TCN research and authors' implementation: https://arxiv.org/abs/1803.01271 and https://github.com/locuslab/TCN
- INCLUDE dataset from AI4Bharat: https://github.com/AI4Bharat/sign-language.ai4bharat.org/blob/master/docs/INCLUDE.md
- ISLRTC: https://islrtc.nic.in/
- MediaPipe Hand Landmarker: https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/python

The TCN paper supports investigating convolutional sequence models; it does not prove TCN will outperform LSTM on this project's ISL data.
