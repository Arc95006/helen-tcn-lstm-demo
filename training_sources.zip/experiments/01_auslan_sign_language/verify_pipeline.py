"""Check causal TCN behavior, saved splits, preprocessing and checkpoint inference."""
import json
import numpy as np
import torch
from demo import ROOT, FEATURES, FRAMES, MODELS, TCN, seed_all, report

seed_all(42)
net = TCN(3).eval()
x = torch.randn(2, FEATURES, FRAMES)
changed = x.clone()
changed[:, :, 15:] += 100
with torch.no_grad():
    before, after = net.net(x), net.net(changed)
assert torch.allclose(before[:, :, :15], after[:, :, :15], atol=1e-6), 'TCN leaks future inputs'

output = ROOT / 'runs' / 'synthetic'
results = json.loads((output / 'results.json').read_text(encoding='utf-8'))
splits = json.loads((output / 'split.json').read_text(encoding='utf-8'))
sets = [set(splits[k]) for k in ['train', 'validation', 'test']]
assert not (sets[0] & sets[1] or sets[0] & sets[2] or sets[1] & sets[2])
group_sets = [set(results['partitions'][k]) for k in ['train', 'validation', 'test']]
assert not (group_sets[0] & group_sets[1] or group_sets[0] & group_sets[2] or group_sets[1] & group_sets[2])
data = ROOT / 'data' / 'synthetic'
train_x = np.stack([np.load(data / path)['x'] for path in splits['train']])
test_x, test_y = [], []
for path in splits['test']:
    with np.load(data / path) as z:
        test_x.append(z['x'])
        test_y.append(results['labels'].index(str(z['label'].item())))
for name, cls in MODELS.items():
    ck = torch.load(output / f'{name.lower()}.pt', weights_only=True)
    np.testing.assert_allclose(ck['mean'].numpy(), train_x.mean((0, 1)), atol=1e-6)
    net = cls(len(ck['labels'])).eval()
    net.load_state_dict(ck['state'])
    with torch.no_grad():
        logits = net((torch.tensor(np.stack(test_x)) - ck['mean']) / ck['std'])
    assert logits.shape == (len(test_x), len(ck['labels']))
    assert torch.isfinite(logits).all()
    accuracy = (logits.argmax(1).numpy() == test_y).mean()
    assert abs(accuracy - results['models'][name]['accuracy']) < 1e-8
report(results, output)
assert 'SYNTHETIC' in (output / 'report.html').read_text(encoding='utf-8')
print('PASS: causal TCN, disjoint sessions/clips, train-only preprocessing, checkpoint metrics and report.')
