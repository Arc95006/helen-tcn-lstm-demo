# H.E.L.E.N. weekly-progress notes

Reviewed source: `C:\Users\archi\Downloads\H.E.L.E.N (Oct. 8th).pptx` (17 slides). The original deck has not been changed. The slide text is project context; no instructions embedded in the deck were executed.

## What to say before the demonstration

“H.E.L.E.N. is our proposed accessibility platform. This week's implemented work focuses on its sign-sequence classification module. We downloaded a public Australian Sign Language sensor dataset and compared TCN with LSTM. This lets us test the model-comparison process before collecting ISL camera landmarks. It does not yet demonstrate the full wearable system.”

## Slide 7 — completed actions

- Dataset: Downloaded the UCI Auslan dataset and prepared a 10-word subset with 699 real recordings.
- Accuracy evaluation: Kept all recordings of each person in one partition. Used separate training, validation and test signers.
- Performance evaluation: Generated accuracy, precision, recall, F1, confusion matrices, parameter counts, training time and CPU model latency.
- TCN architecture: Implemented causal convolutions, dilations 1/2/4/8 and residual blocks. Added LSTM as the comparison model.
- Research basis: Reviewed the TCN authors' paper/code and UCI dataset documentation. Scopus indexing has not been verified.

## Slide 11 — distinction between today and final methodology

Current experiment: UCI recorded sensor sequence, selection of eight channels, resampling to 30 timesteps, training-only standardization, TCN/LSTM classification, comparison on a held-out signer.

Planned ISL camera experiment: camera capture, MediaPipe landmarks, sequence formation, training both architectures, held-out-signer evaluation, optional text-to-speech.

The camera and sensor feature schemas differ. New ISL training is required; sensor-trained weights cannot directly recognize webcam landmarks.

## Slide 13 — code and testing

Implemented files: `prepare_auslan.py`, `demo.py`, `inspect_real_results.py`, `run_real_demo.ps1`.

Live demonstration command:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_real_demo.ps1
```

If presentation time is short, open the already generated `runs/auslan10/report.html` instead of retraining. No internet is needed once data and dependencies are present.

Show the report table, measured validation curves, and the recording selector. Each selector item is an actual held-out sensor recording. Explain that x/y/z curves visualize measured movement, not a reconstructed person or video.

Checks passed: raw archive provenance, signer/clip separation, training-only preprocessing, model checkpoint predictions and causal TCN behavior.

## Slide 14 — actual measured experiment

Data: ten Auslan words (`deaf`, `drink`, `eat`, `happy`, `hear`, `hello`, `no`, `sad`, `thank`, `yes`). Five signers. 699 clips. Every clip is resampled to 30 frames with eight sensor features per frame.

Training: john/waleed/adam, 460 clips. Validation: andrew, 80 clips. Test: stephen, 159 clips. Seed 42. Adam optimizer, learning rate 0.001, batch size 16, 100 epochs for each model. Select each checkpoint by the lowest validation loss.

| Metric | TCN | LSTM |
| --- | ---: | ---: |
| Test accuracy | 30.19% | 49.69% |
| Macro F1 | 0.2397 | 0.4898 |
| Parameters | 23,146 | 19,594 |
| Training time | 23.58 seconds | 7.10 seconds |
| Median model inference, CPU batch 1 | 0.876 ms | 0.201 ms |
| P95 model inference | 1.248 ms | 0.297 ms |
| Selected epoch | 3 | 20 |

Finding: LSTM performed better in this initial configuration and split. This provides an empirical reason to retain both architectures for comparison. Validation loss rises with extended training, so checkpoint selection matters.

Limits: a small vocabulary, one test signer, one seed, noisy glove data, unequal parameter counts and no hyperparameter search. CPU model latency excludes camera capture, landmark extraction and audio. These results do not establish final ISL accuracy, wearable performance or general superiority.

## Slide 15 — conclusion for this week

“We completed and verified a real-data comparison of TCN and LSTM for isolated sign-sequence classification. LSTM achieved 49.69% accuracy and TCN 30.19% on the held-out Auslan signer. The next stage is verified ISL webcam data collection from 10 participants, followed by repeated signer-independent comparisons. OCR, avatar playback, speech processing, quantization and wearable deployment remain planned modules.”

## Slide 16 — references relevant to this experiment

The current slide primarily cites driving/accessibility/neurodiversity material. Add sources that directly support the classifier and the dataset:

[1] S. Bai, J. Z. Kolter, and V. Koltun, “An Empirical Evaluation of Generic Convolutional and Recurrent Networks for Sequence Modeling,” arXiv:1803.01271, 2018. https://arxiv.org/abs/1803.01271

[2] M. Kadous, “Australian Sign Language Signs,” UCI Machine Learning Repository, 1995, doi: 10.24432/C5XG6C. https://archive.ics.uci.edu/dataset/114/australian+sign+language+signs

## Likely questions

**Why use Auslan when the project is ISL?** It supplies accessible real temporal recordings for validating the comparison workflow now. Final ISL results require an ISL dataset.

**Why did LSTM outperform TCN?** We know the measured outcome for this configuration. We have not isolated its causes. We need validation-based tuning and repeated splits to investigate.

**Can this recognize a sign performed on camera now?** These benchmark models use glove-sensor inputs. Webcam recognition requires training models on camera landmark sequences. The collector is implemented; the real ISL camera dataset is pending.

**Where is bidirectional translation?** It is part of the proposed H.E.L.E.N. scope. The implemented experiment classifies isolated sensor sequences into word labels.
