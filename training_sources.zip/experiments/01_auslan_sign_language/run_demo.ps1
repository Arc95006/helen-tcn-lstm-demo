$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$taskPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $taskPython)) {
    throw 'Project Python environment is missing. See README.md for setup.'
}
if (-not (Test-Path -LiteralPath 'data\synthetic')) {
    & $taskPython demo.py synthetic
    if ($LASTEXITCODE -ne 0) { throw 'Synthetic generation failed.' }
}
& $taskPython demo.py train --dataset synthetic --epochs 40
if ($LASTEXITCODE -ne 0) { throw 'Training failed.' }
Start-Process -FilePath (Join-Path $PSScriptRoot 'runs\synthetic\report.html')
