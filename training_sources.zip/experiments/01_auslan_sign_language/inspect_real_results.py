"""Verify real-data results and add held-out sensor recordings to the demo report."""
import csv
import json
import numpy as np
import torch
from demo import ROOT, MODELS, metrics, report, seed_all


def main():
    seed_all(42)
    folder, output = ROOT / 'data' / 'auslan10', ROOT / 'runs' / 'auslan10'
    results = json.loads((output / 'results.json').read_text(encoding='utf-8'))
    metadata = json.loads((folder / 'metadata.json').read_text(encoding='utf-8'))
    splits = json.loads((output / 'split.json').read_text(encoding='utf-8'))
    groups = [set(results['partitions'][k]) for k in ['train', 'validation', 'test']]
    assert not (groups[0] & groups[1] or groups[0] & groups[2] or groups[1] & groups[2])
    sets = [set(splits[k]) for k in ['train', 'validation', 'test']]
    assert not (sets[0] & sets[1] or sets[0] & sets[2] or sets[1] & sets[2])
    provenance = {m['file']: m for m in metadata['clip_manifest']}
    for part, files in splits.items():
        assert all(provenance[path]['signer'] in results['partitions'][part] for path in files)
    train = np.stack([np.load(folder / f)['x'] for f in splits['train']])
    xs, ys, previews = [], [], []
    for filename in splits['test']:
        with np.load(folder / filename) as z:
            xs.append(z['x'])
            ys.append(results['labels'].index(str(z['label'].item())))
    probabilities = {}
    rows = []
    for name, cls in MODELS.items():
        ck = torch.load(output / f'{name.lower()}.pt', weights_only=True)
        assert ck['input_features'] == 8
        np.testing.assert_allclose(ck['mean'].numpy(), train.mean((0, 1)), atol=1e-6)
        np.testing.assert_allclose(ck['std'].numpy(), np.maximum(train.std((0, 1)), .05), atol=1e-6)
        net = cls(len(ck['labels']), input_features=8).eval()
        net.load_state_dict(ck['state'])
        with torch.no_grad():
            p = net((torch.tensor(np.stack(xs)) - ck['mean']) / ck['std']).softmax(1).numpy()
        assert np.isfinite(p).all()
        probabilities[name] = p
        measured = metrics(np.array(ys), p.argmax(1), len(ck['labels']))
        for field in ['accuracy', 'macro_f1', 'confusion_matrix']:
            assert measured[field] == results['models'][name][field], f'{name}: saved metric mismatch'
        cm = np.array(measured['confusion_matrix'])
        precision = np.diag(cm) / np.maximum(cm.sum(0), 1)
        recall = np.diag(cm) / np.maximum(cm.sum(1), 1)
        results['models'][name].update(macro_precision=float(precision.mean()), macro_recall=float(recall.mean()))
        for c, label in enumerate(ck['labels']):
            rows.append([name, label, int(cm[c].sum()), precision[c], recall[c], 2*cm[c,c]/max(cm[c].sum()+cm[:,c].sum(),1)])
    with (output / 'class_metrics.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['model', 'label', 'test_support', 'precision', 'recall', 'f1'])
        w.writerows(rows)
    # Two deterministic held-out recordings per word; never select examples by correctness.
    for c, label in enumerate(results['labels']):
        for i in np.flatnonzero(np.array(ys) == c)[:2]:
            predictions = {}
            for name, p in probabilities.items():
                predicted = int(p[i].argmax())
                predictions[name] = {'label': results['labels'][predicted], 'confidence': float(p[i, predicted])}
            previews.append({'label': label, 'signer': provenance[splits['test'][i]]['signer'],
                             'file': splits['test'][i], 'trace': xs[i][:, :3].tolist(), 'predictions': predictions})
    metadata['sample_previews'] = previews
    # Avoid copying the complete provenance list into the visible results file.
    results['data_metadata'] = {k: v for k, v in metadata.items() if k != 'clip_manifest'}
    results['note'] = metadata['evaluation_note'] + ' Latency is model-only, batch=1, CPU, excludes capture and feature extraction.'
    (output / 'results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    report(results, output)
    print('PASS: real-data provenance, disjoint signers/clips, training-only normalization and checkpoint accuracy/F1/confusion matrices.')
    print('Held-out examples added to report; class metrics saved.')


if __name__ == '__main__':
    main()
