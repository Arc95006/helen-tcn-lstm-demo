$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$taskPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $taskPython)) { throw 'Missing project environment. See README.md.' }
& $taskPython prepare_auslan.py
if ($LASTEXITCODE -ne 0) { throw 'Real dataset preparation failed.' }
& $taskPython demo.py train --dataset auslan10 --epochs 100 --seed 42
if ($LASTEXITCODE -ne 0) { throw 'Training failed.' }
& $taskPython inspect_real_results.py
if ($LASTEXITCODE -ne 0) { throw 'Real data verification failed.' }
Start-Process -FilePath (Join-Path $PSScriptRoot 'runs\auslan10\report.html')
