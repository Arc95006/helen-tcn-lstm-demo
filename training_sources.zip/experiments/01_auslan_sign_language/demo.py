"""Small, honest isolated-sign TCN/LSTM comparison. See README.md."""
import argparse
import copy
import csv
import html
import json
import os
from pathlib import Path
import random
import time
import urllib.request

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mplcache'))
FRAMES, FEATURES = 30, 128
MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'


class CausalConv(nn.Module):
    def __init__(self, a, b, dilation):
        super().__init__()
        self.pad = 2 * dilation
        self.conv = nn.Conv1d(a, b, 3, dilation=dilation)

    def forward(self, x):
        return self.conv(F.pad(x, (self.pad, 0)))


class Block(nn.Module):
    def __init__(self, a, b, dilation):
        super().__init__()
        self.net = nn.Sequential(CausalConv(a, b, dilation), nn.ReLU(), nn.Dropout(.15),
                                 CausalConv(b, b, dilation), nn.ReLU(), nn.Dropout(.15))
        self.skip = nn.Conv1d(a, b, 1) if a != b else nn.Identity()

    def forward(self, x):
        return F.relu(self.net(x) + self.skip(x))


class TCN(nn.Module):
    def __init__(self, classes, input_features=FEATURES):
        super().__init__()
        self.net = nn.Sequential(Block(input_features, 32, 1), Block(32, 32, 2),
                                 Block(32, 32, 4), Block(32, 32, 8))
        self.head = nn.Linear(32, classes)

    def forward(self, x):
        return self.head(self.net(x.transpose(1, 2))[:, :, -1])


class LSTM(nn.Module):
    def __init__(self, classes, input_features=FEATURES):
        super().__init__()
        self.net = nn.LSTM(input_features, 64, batch_first=True)
        self.head = nn.Sequential(nn.Dropout(.15), nn.Linear(64, classes))

    def forward(self, x):
        _, (h, _) = self.net(x)
        return self.head(h[-1])


MODELS = {'TCN': TCN, 'LSTM': LSTM}


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(2)


def save_clip(folder, label, session, x):
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f'{time.time_ns()}.npz'
    np.savez_compressed(path, x=np.asarray(x, dtype=np.float32), label=label, session=session)


def synthetic(args):
    folder = ROOT / 'data' / 'synthetic'
    rng = np.random.default_rng(args.seed)
    # Mathematical trajectories, deliberately NOT ISL hand poses.
    for session in ['session_a', 'session_b', 'session_c', 'session_d', 'session_e']:
        shift = rng.normal(0, .05, (1, FEATURES))
        for c, label in enumerate(['synthetic_wave', 'synthetic_ramp', 'synthetic_pulse']):
            for _ in range(args.clips):
                t = np.linspace(0, 1, FRAMES)
                if c == 0:
                    curve = np.sin(2 * np.pi * t)
                elif c == 1:
                    curve = 2 * t - 1
                else:
                    curve = np.where((t > .3) & (t < .7), 1., -1.)
                x = rng.normal(0, .08, (FRAMES, FEATURES)) + shift
                x[:, :12] += curve[:, None] * rng.uniform(.7, 1.3)
                save_clip(folder, label, session, x)
    print(f'Saved synthetic clips in {folder}. These are NOT ISL data.')


def load_data(folder):
    xs, labels, sessions, files = [], [], [], []
    for path in sorted(folder.glob('*.npz')):
        with np.load(path, allow_pickle=False) as z:
            x = z['x'].astype(np.float32)
            if x.ndim != 2 or x.shape[0] != FRAMES or not np.isfinite(x).all():
                raise ValueError(f'Invalid sequence: {path}')
            xs.append(x)
            labels.append(str(z['label'].item()))
            sessions.append(str(z['session'].item()))
            files.append(path.name)
    if not xs:
        raise ValueError(f'No clips in {folder}. Record clips or run synthetic first.')
    names = sorted(set(labels))
    if len(names) < 2:
        raise ValueError('Need at least two labels.')
    return np.stack(xs), np.array([names.index(v) for v in labels]), np.array(sessions), names, files


def metrics(y, pred, classes):
    cm = np.zeros((classes, classes), dtype=int)
    np.add.at(cm, (y, pred), 1)
    tp = np.diag(cm)
    f1 = 2 * tp / np.maximum(cm.sum(0) + cm.sum(1), 1)
    return {'accuracy': float((y == pred).mean()), 'macro_f1': float(f1.mean()),
            'confusion_matrix': cm.tolist()}


def train(args):
    seed_all(args.seed)
    folder = ROOT / 'data' / args.dataset
    x, y, sessions, labels, files = load_data(folder)
    groups = sorted(set(sessions))
    if len(groups) < 3:
        raise ValueError('Record at least 3 separate sessions, each containing every sign. Sessions stay separate between train/validation/test.')
    random.Random(args.seed).shuffle(groups)
    partitions = {'train': groups[2:], 'validation': groups[1:2], 'test': groups[:1]}
    idx = {k: np.flatnonzero(np.isin(sessions, v)) for k, v in partitions.items()}
    for key, ids in idx.items():
        if set(y[ids]) != set(range(len(labels))):
            raise ValueError(f'{key} split lacks a label. Record every label in every session.')
    # Fit preprocessing only to the training partition.
    mean = x[idx['train']].mean((0, 1))
    std = np.maximum(x[idx['train']].std((0, 1)), .05)
    xx = torch.tensor((x - mean) / std)
    yy = torch.tensor(y, dtype=torch.long)
    output = ROOT / 'runs' / args.dataset
    output.mkdir(parents=True, exist_ok=True)
    results = {'dataset': args.dataset, 'synthetic': args.dataset == 'synthetic', 'labels': labels,
               'seed': args.seed, 'partitions': partitions, 'counts': {k: len(v) for k, v in idx.items()},
               'input_features': x.shape[-1], 'frames': FRAMES, 'epochs': args.epochs,
               'note': 'Session holdout; not signer-independent unless sessions correspond to different signers. Latency is model-only, batch=1, CPU, excludes camera/landmarks.',
               'models': {}}
    metadata = folder / 'metadata.json'
    if metadata.exists():
        results['data_metadata'] = json.loads(metadata.read_text(encoding='utf-8'))
        results['note'] = results['data_metadata']['evaluation_note'] + ' Latency is model-only, batch=1, CPU, excludes capture and feature extraction.'
    manifest = {key: [files[i] for i in ids] for key, ids in idx.items()}
    (output / 'split.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    for name, cls in MODELS.items():
        seed_all(args.seed)
        model = cls(len(labels), input_features=x.shape[-1])
        opt = torch.optim.Adam(model.parameters(), lr=.001)
        best_loss, best, best_epoch, history = float('inf'), None, 0, []
        start = time.perf_counter()
        for epoch in range(args.epochs):
            model.train()
            order = idx['train'][np.random.permutation(len(idx['train']))]
            for off in range(0, len(order), 16):
                ids = order[off:off + 16]
                opt.zero_grad()
                loss = F.cross_entropy(model(xx[ids]), yy[ids])
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 1.)
                opt.step()
            model.eval()
            with torch.no_grad():
                val_loss = F.cross_entropy(model(xx[idx['validation']]), yy[idx['validation']]).item()
            history.append(val_loss)
            if val_loss < best_loss:
                best_loss, best, best_epoch = val_loss, copy.deepcopy(model.state_dict()), epoch + 1
            if (epoch + 1) % 10 == 0:
                print(f'{name}: epoch {epoch + 1}/{args.epochs}, validation loss {val_loss:.4f}', flush=True)
        seconds = time.perf_counter() - start
        model.load_state_dict(best)
        model.eval()
        with torch.no_grad():
            pred = model(xx[idx['test']]).argmax(1).numpy()
            sample = xx[idx['test'][:1]]
            for _ in range(20):
                model(sample)
            timings = []
            for _ in range(100):
                begin = time.perf_counter()
                model(sample)
                timings.append((time.perf_counter() - begin) * 1000)
        result = metrics(y[idx['test']], pred, len(labels))
        result.update(parameters=sum(p.numel() for p in model.parameters()), training_seconds=seconds,
                      latency_median_ms=float(np.median(timings)), latency_p95_ms=float(np.percentile(timings, 95)),
                      best_epoch=best_epoch, validation_loss=history)
        results['models'][name] = result
        torch.save({'state': best, 'mean': torch.tensor(mean), 'std': torch.tensor(std),
                    'labels': labels, 'dataset': args.dataset,
                    'input_features': x.shape[-1]}, output / f'{name.lower()}.pt')
        print(name, {k: v for k, v in result.items() if k not in ['validation_loss', 'confusion_matrix']})
    (output / 'results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    with (output / 'comparison.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['model', 'accuracy', 'macro_f1', 'parameters', 'training_seconds', 'latency_median_ms', 'latency_p95_ms'])
        for name, r in results['models'].items():
            writer.writerow([name] + [r[k] for k in ['accuracy', 'macro_f1', 'parameters', 'training_seconds', 'latency_median_ms', 'latency_p95_ms']])
    report(results, output)
    print(f'Open {output / "report.html"}')


def report(results, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8, 3.5))
    for name, r in results['models'].items():
        ax.plot(range(1, len(r['validation_loss']) + 1), r['validation_loss'], label=name)
    ax.set(xlabel='Epoch', ylabel='Validation cross-entropy', title='Measured validation learning curves')
    ax.legend()
    ax.grid(alpha=.2)
    fig.tight_layout()
    fig.savefig(output / 'learning_curves.png', dpi=160)
    plt.close(fig)
    esc = html.escape
    rows, matrices = '', ''
    for name, r in results['models'].items():
        rows += f'<tr><td>{name}</td><td>{100*r["accuracy"]:.1f}%</td><td>{r["macro_f1"]:.3f}</td><td>{r["parameters"]:,}</td><td>{r["training_seconds"]:.2f}s</td><td>{r["latency_median_ms"]:.3f}ms</td><td>{r["latency_p95_ms"]:.3f}ms</td></tr>'
        matrices += f'<h3>{name}: confusion matrix</h3><p>Rows = actual; columns = predicted. Labels: {esc(", ".join(results["labels"]))}</p><pre>{esc(np.array2string(np.array(r["confusion_matrix"])))}</pre>'
    metadata = results.get('data_metadata', {})
    banner = 'SYNTHETIC PIPELINE DEMO — these results are not ISL accuracy.' if results['synthetic'] else metadata.get('banner', 'SMALL SELF-RECORDED PROTOTYPE — results apply only to this held-out session.')
    dataset_name = metadata.get('display_name', results['dataset'])
    source = metadata.get('source_url')
    attribution = f'<p>Data: <a href="{esc(source, quote=True)}">{esc(metadata.get("citation", "Dataset source"))}</a>. {esc(metadata.get("license_note", ""))}</p>' if source else ''
    features_count = results.get('input_features', FEATURES)
    example = ''
    sample_data = metadata.get('sample_previews', [])
    if sample_data:
        options = ''.join(f'<option value="{i}">{esc(s["label"])} — {esc(s["signer"])} — clip {i % 2 + 1}</option>' for i, s in enumerate(sample_data))
        example = f'<h2>Real held-out recordings</h2><p>Select a recording to view its measured hand-position trace and both model predictions. This trace comes from glove sensors; it is not video or an anatomical animation. Each coordinate is scaled separately for display.</p><select id="sample" onchange="showSample()">{options}</select><div id="prediction"></div><svg id="trace" viewBox="0 0 700 220" style="width:100%;background:#172237;margin-top:20px"></svg>'
        # Escape HTML-sensitive characters in JSON embedded into script elements.
        serialized = json.dumps(sample_data).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
        example += '<script>const samples=' + serialized + ''';
function showSample(){const s=samples[Number(document.getElementById('sample').value)];
const p=document.getElementById('prediction');p.textContent='Actual: '+s.label+' | '+Object.entries(s.predictions).map(([k,v])=>k+': '+v.label+' ('+(v.confidence*100).toFixed(1)+'%)').join(' | ');
const svg=document.getElementById('trace');svg.replaceChildren();const colors=['#68d5ff','#ffbd69','#a4edb7'];
for(let c=0;c<3;c++){let vals=s.trace.map(r=>r[c]);let lo=Math.min(...vals),hi=Math.max(...vals);let points=vals.map((v,i)=>`${30+i*640/(vals.length-1)},${190-(v-lo)*150/Math.max(hi-lo,0.001)}`).join(' ');
const line=document.createElementNS('http://www.w3.org/2000/svg','polyline');line.setAttribute('points',points);line.setAttribute('fill','none');line.setAttribute('stroke',colors[c]);line.setAttribute('stroke-width','3');svg.appendChild(line);
const text=document.createElementNS('http://www.w3.org/2000/svg','text');text.setAttribute('x',30+210*c);text.setAttribute('y','20');text.setAttribute('fill',colors[c]);text.textContent=['x position','y position','z position'][c];svg.appendChild(text);}}
showSample();</script>'''
    page = f'''<!doctype html><html><head><meta charset="utf-8"><title>TCN vs LSTM</title><style>
body{{background:#0b1220;color:#e5ecf7;font:17px system-ui;max-width:1080px;margin:50px auto;padding:24px;overflow-wrap:anywhere}}h1{{font-size:42px}}.notice{{background:#47371b;padding:20px;border-radius:12px}}.tablewrap{{overflow-x:auto}}table{{width:100%;min-width:850px;border-collapse:collapse;margin:28px 0}}th,td{{padding:14px;text-align:left;border-bottom:1px solid #34435b}}pre{{background:#172237;padding:20px;overflow-x:auto}}select{{max-width:100%;padding:12px;background:#172237;color:#e5ecf7;border:1px solid #34435b;border-radius:6px}}p{{line-height:1.6}}a{{color:#8cd4ff}}</style></head>
<body><p>ISOLATED SIGN RECOGNITION · MODEL COMPARISON</p><h1>TCN vs LSTM</h1><div class="notice">{banner}</div>
<h2>{esc(dataset_name)}</h2>{attribution}<p>{FRAMES} frames → {features_count} features per frame → sequence classifier → sign label. Both models use identical clips, preprocessing, partitions, epoch budget and optimizer settings. Each checkpoint is selected using validation loss.</p>
<div class="tablewrap"><table><tr><th>Model</th><th>Test accuracy</th><th>Macro F1</th><th>Parameters</th><th>Train time</th><th>Median latency</th><th>P95 latency</th></tr>{rows}</table></div>
<p>{esc(results['note'])}</p><p>Clip counts: {esc(str(results['counts']))}. Seed: {results['seed']}. Epoch budget: {results.get('epochs', 'n/a')}. A single small experiment cannot establish which architecture is generally better. Parameter counts differ.</p><p>Groups: {esc(str(results['partitions']))}</p><img src="learning_curves.png" alt="Validation loss by epoch for both models" style="width:100%;max-width:800px">{example}{matrices}
<p>Scope: isolated vocabulary. Facial expression, body pose, continuous sentence translation and speech-to-ISL are outside this prototype. Sensor-trained models cannot directly classify webcam landmarks.</p></body></html>'''
    (output / 'report.html').write_text(page, encoding='utf-8')


def landmarker():
    import mediapipe as mp
    path = ROOT / 'assets' / 'hand_landmarker.task'
    if not path.exists():
        raise ValueError('Missing landmark model. Run: python demo.py download-model')
    options = mp.tasks.vision.HandLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_path=str(path)), num_hands=2,
        running_mode=mp.tasks.vision.RunningMode.VIDEO)
    return mp.tasks.vision.HandLandmarker.create_from_options(options)


def features(result):
    out = np.zeros(FEATURES, dtype=np.float32)
    # Fixed handedness slots; global x/y retain movement and two-hand relationship.
    for landmarks, handedness in zip(result.hand_landmarks, result.handedness):
        slot = 0 if handedness[0].category_name == 'Left' else 1
        if out[126 + slot]:
            continue
        points = np.array([[p.x, p.y, p.z] for p in landmarks], dtype=np.float32)
        out[slot * 63:(slot + 1) * 63] = points.reshape(-1)
        out[126 + slot] = 1
    return out


def camera(args, live=False):
    import cv2
    import mediapipe as mp
    seed_all(42)
    loaded = {}
    if live:
        if args.dataset == 'synthetic' or args.dataset.startswith('auslan'):
            raise ValueError('Synthetic or glove-sensor models cannot recognize webcam signs. Train recorded camera data for live mode.')
        for name, cls in MODELS.items():
            ck = torch.load(ROOT / 'runs' / args.dataset / f'{name.lower()}.pt', weights_only=True)
            if ck.get('input_features', FEATURES) != FEATURES:
                raise ValueError('Checkpoint feature schema differs from webcam landmarks.')
            net = cls(len(ck['labels']))
            net.load_state_dict(ck['state'])
            loaded[name] = (net.eval(), ck)
    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise ValueError('Cannot open camera. Try --camera 1; close other webcam apps.')
    message = 'SPACE: record a 2-second sign; Q: quit'
    collected, remaining, recording, next_frame = [], args.clips if not live else 0, False, 0
    started = time.perf_counter()
    try:
        with landmarker() as detector:
            while True:
                ok, frame = cap.read()
                if not ok:
                    raise ValueError('Camera frame unavailable.')
                # Same unmirrored orientation during collection and inference.
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                timestamp = int((time.perf_counter() - started) * 1000)
                result = detector.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb), timestamp)
                for hand in result.hand_landmarks:
                    for p in hand:
                        cv2.circle(frame, (int(p.x * frame.shape[1]), int(p.y * frame.shape[0])), 3, (70, 240, 120), -1)
                now = time.perf_counter()
                if recording and now >= next_frame:
                    collected.append(features(result))
                    next_frame = now + 1 / 15
                    if len(collected) == FRAMES:
                        recording = False
                        x = np.stack(collected)
                        if (x[:, 126:].sum(1) > 0).mean() < .6:
                            message = 'Too few detected hands. SPACE: try again'
                        elif live:
                            pieces = []
                            with torch.no_grad():
                                for name, (net, ck) in loaded.items():
                                    probs = net((torch.tensor(x)[None] - ck['mean']) / ck['std']).softmax(1)[0]
                                    score, ix = probs.max(0)
                                    label = ck['labels'][int(ix)] if score >= args.threshold else 'uncertain'
                                    pieces.append(f'{name}: {label} ({score:.0%})')
                            message = ' | '.join(pieces)
                            print(message, flush=True)
                        else:
                            save_clip(ROOT / 'data' / args.dataset, args.label, args.session, x)
                            remaining -= 1
                            message = f'Saved {args.label}. {remaining} clips left. SPACE: next'
                            if remaining == 0:
                                print(message)
                                break
                display = f'Recording {len(collected)}/{FRAMES}' if recording else message
                cv2.putText(frame, display, (12, 30), cv2.FONT_HERSHEY_SIMPLEX, .55, (255, 255, 255), 2)
                cv2.putText(frame, 'SPACE: start when ready | Q: quit | isolated signs only', (12, 60), cv2.FONT_HERSHEY_SIMPLEX, .5, (255, 255, 255), 1)
                cv2.imshow('TCN / LSTM - controlled webcam demonstration', frame)
                key = cv2.waitKey(1) & 0xff
                if key == ord('q'):
                    break
                if key == 32 and not recording:
                    collected, recording, next_frame = [], True, time.perf_counter()
    finally:
        cap.release()
        cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('synthetic')
    p.add_argument('--clips', type=int, default=20)
    p.add_argument('--seed', type=int, default=42)
    sub.add_parser('download-model')
    p = sub.add_parser('train')
    p.add_argument('--dataset', default='recorded')
    p.add_argument('--epochs', type=int, default=60)
    p.add_argument('--seed', type=int, default=42)
    for command in ['collect', 'live']:
        p = sub.add_parser(command)
        p.add_argument('--dataset', default='recorded')
        p.add_argument('--camera', type=int, default=0)
        if command == 'collect':
            p.add_argument('--label', required=True)
            p.add_argument('--session', required=True)
            p.add_argument('--clips', type=int, default=10)
        else:
            p.add_argument('--threshold', type=float, default=.8)
    args = parser.parse_args()
    if hasattr(args, 'dataset') and (not args.dataset or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in args.dataset)):
        parser.error('Dataset name must contain only letters, digits, underscores or hyphens.')
    if getattr(args, 'clips', 1) < 1 or getattr(args, 'epochs', 1) < 1:
        parser.error('Clips and epochs must be positive.')
    if args.command == 'synthetic':
        synthetic(args)
    elif args.command == 'train':
        train(args)
    elif args.command == 'download-model':
        path = ROOT / 'assets' / 'hand_landmarker.task'
        path.parent.mkdir(exist_ok=True)
        urllib.request.urlretrieve(MODEL_URL, path)
        print(f'Downloaded {path}')
    else:
        camera(args, live=args.command == 'live')


if __name__ == '__main__':
    main()
