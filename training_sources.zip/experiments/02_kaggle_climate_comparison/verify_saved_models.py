"""Check four restored final models against the saved 2017 predictions."""
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mplcache'))
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from load_model import load_saved_model

df = pd.concat([pd.read_csv(ROOT / 'datasets/DelhiClimate' / name, index_col='date', parse_dates=True)
                for name in ['DailyDelhiClimateTrain.csv', 'DailyDelhiClimateTest.csv']])
saved = pd.read_csv(ROOT / 'outputs/predictions.csv')
for features, suffix in [(['meantemp'], 'one'), (['meantemp', 'humidity'], 'two')]:
    train = df.loc[df.index.year != 2017, features]
    xs = MinMaxScaler().fit(train)
    ys = MinMaxScaler().fit(train.meantemp.to_numpy()[30:].reshape(-1, 1))
    data = xs.transform(df[features].iloc[-145:])
    windows = np.stack([data[i:i+30] for i in range(115)])
    for architecture in ['lstm', 'tcn']:
        model = load_saved_model(f'{architecture}_{suffix}_feature_final')
        # Direct inference avoids the overhead of creating a dataset per batch.
        pred = ys.inverse_transform(model(windows, training=False).numpy()).ravel()
        np.testing.assert_allclose(pred, saved[f'{architecture}_pred_{suffix}_ft'], atol=1e-4, rtol=1e-5)
        print(f'PASS: restored {architecture} {suffix}-feature model reproduces saved predictions.')
