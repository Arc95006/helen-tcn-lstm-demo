# Kaggle LSTM vs TCN climate comparison

This folder reproduces **Ricardo Colindres's “LSTM vs TCN for Time Series Analysis Comparison”**:

https://www.kaggle.com/code/ricardocolindres/lstm-vs-tcn-for-time-series-analysis-comparison

It uses the exact Daily Delhi Climate CSV files downloaded from the notebook's input dataset. It is a numerical temperature-forecasting project, not a sign-language classifier.

## Run

From this folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_demo.ps1
```

From the parent project folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\02_kaggle_climate_comparison\run_demo.ps1
```

The environment and public dataset are already installed locally. The script runs every original notebook cell in order, trains eight model instances, captures plots/tables/summaries, verifies metrics, and opens a report. It can take several minutes on CPU. After installation/download, no network is required.

To open existing results without retraining, double-click `outputs/report.html`. Use `outputs/notebook.html` for the complete executed notebook with code and results in original order. `local_notebook.ipynb` is the editable local notebook with compatibility changes applied and outputs cleared; select this folder's `.venv` as its Python environment when opening it in a notebook editor. The notebook assumes the CSVs have already been prepared by `reproduce.py`.

## What is preserved

- Original dataset, exploratory analysis and decomposition plots.
- A 30-record input window and one-step temperature target.
- Temperature-only and temperature-plus-humidity variants of both models.
- Two stacked LSTM layers (64 then 128 units) and a Dense(1) output.
- keras-tcn's TCN with 64 filters, kernel size 3, dilations [1,2,4,8], layer normalization, dropout 0.02 and a Dense(1) output.
- Adam optimizer and MSE loss.
- Initial chronological 80/20 development split, original early-stopping patience and epoch limits.
- Final models retrained for 47 epochs on all non-2017 records.
- One-step 2017 predictions and the original recursive prediction experiment.

## Documented adaptations

This reproduces the method rather than claiming identical random weights or a pixel-identical old-library display. Local seed 42, TensorFlow 2.19.1/current Keras, CPU thread limits, matplotlib output capture, callback-list syntax, and one leading-space typo correction are documented in `outputs/adaptations.json`. No epoch reduction or architecture change is made.

Original behavior retained for transparency: MinMax scaling before the initial internal 80/20 split, duplicate 1 January 2017 date, and the source recursion's direct insertion of output-scaled predictions into input-scaled windows. Those choices are explained in `RESULTS_EXPLAINED.md`.

## Files

| File/folder | Purpose |
| --- | --- |
| `reference/original_kaggle.ipynb` | Unmodified notebook source downloaded from Kaggle API |
| `reference/original_rendered.html` | Saved visible published notebook, including its numeric outputs |
| `reference/daily_climate.zip` | Exact input dataset archive |
| `reference/LICENSE-2.0.txt` | Notebook's Apache 2.0 license |
| `datasets/DelhiClimate/` | Prepared train/test CSV files |
| `reproduce.py` | Execute original cells with documented compatibility changes |
| `explain_results.py` | Verify predictions and create report/explanation |
| `outputs/executed_notebook.ipynb` | Locally executed notebook and outputs |
| `outputs/notebook.html` | Self-contained rendered local notebook |
| `outputs/report.html` | Concise results and plots in source order |
| `outputs/figures/` | All reproduced plot images |
| `outputs/models/` | Eight sets of trained NumPy weights and matching architecture JSON files |
| `outputs/predictions.csv` | Observations, predictions and squared errors |
| `outputs/comparison_with_kaggle.csv` | Published numbers beside newly measured local results |
| `RESULTS_EXPLAINED.md` | Easy explanation of every stage and result |
| `environment-lock.txt` | Installed dependency versions |

## Attribution

Original notebook author: **Ricardo Colindres**, Apache 2.0 license, version 1. The reproduction retains the original cell content and labels its additions. See `reference/NOTICE.md` and `reference/LICENSE-2.0.txt`.

Dataset: **Sumanth Rao**, Daily Climate time series data, https://www.kaggle.com/datasets/sumanthvrao/daily-climate-time-series-data.

TCN library: https://github.com/philipperemy/keras-tcn.

The published notebook's numerical results and our local experiment are clearly separated. Do not present the author's original numbers as measurements from this computer.

Completed local run: all original cells, eight trained model instances, 27 reproduced figures and 115 forecast records. The full execution took approximately five minutes after imports/data preparation on this computer. Final temperature-only LSTM RMSE was 1.849131 °C; temperature-plus-humidity TCN was close at 1.855213 °C. Full results and explanation are in `RESULTS_EXPLAINED.md`.

Saved-model checks passed for all four final variants:

```powershell
.\.venv\Scripts\python.exe verify_saved_models.py
```

`load_model.py` restores a trained architecture and its weights without retraining.

Model saving is an artifact-only addition. A local `.keras` saving stall led to saving each model's learned weights as `.npz` plus its Keras architecture JSON instead. The source notebook does not save models, and this change does not affect its training or predictions.
