# Delhi climate notebook: results explained

Source: Ricardo Colindres, [LSTM vs TCN for Time Series Analysis Comparison](https://www.kaggle.com/code/ricardocolindres/lstm-vs-tcn-for-time-series-analysis-comparison), Apache 2.0.

This project reproduces the notebook's analysis and model settings. It forecasts a numerical temperature, so it is a regression experiment. Accuracy percentages used for sign classification are not appropriate here.

## What the outputs mean, in notebook order

**Dataset shape and missing-value check.** The combined files have 1,576 records and four measured variables. The null-count output is zero for every variable. The combined files have two records dated 1 January 2017; the reproduction retains both, matching the notebook. “30 days” therefore means 30 consecutive records in this code.

**Description table.** Count is the number of observations; mean is the average; std measures spread; min/max and quartiles describe the range. The pressure extremes make it unsuitable to assume every measurement is clean.

**Pair plot and correlation heatmap.** These compare variable relationships. A negative temperature/humidity correlation indicates a tendency to move in opposite directions; it does not establish causation. The forecasting models later use temperature alone, or temperature and humidity.

**Normalized temperature and humidity graphs.** Standardization puts quantities with different units on a comparable display scale. This exploratory StandardScaler does not train the forecasting models. Their preprocessing separately uses MinMaxScaler.

**Yearly curves and box plots.** Curves reveal repeating annual patterns. Box plots summarize each year/month's spread, median and unusually distant observations.

**Seasonal decomposition.** The moving-average and polynomial approaches separate temperature into a longer-term trend, recurring monthly pattern and residual variation. Those components help explain the data, but they are not the inputs fed into the LSTM/TCN training cells. The residual includes whatever these simple trend/seasonal approximations do not explain; a plot alone does not prove it is entirely random.

**Autocorrelation.** This plots the relationship between a temperature value and earlier values at different lags. It helps illustrate temporal dependence and recurring patterns.

**Initial train/validation experiments.** A sample consists of 30 consecutive records used to predict the next temperature. Data from 2017 are excluded. The first 80% of the resulting samples train the model, while the last 20% appear as `X_test`/`y_test` in code and also supply validation losses. Treat this initial segment as validation/model development because the notebook uses it during training.

**Model summaries.** LSTM has stacked 64-unit and 128-unit recurrent layers, then one numerical output. TCN has 64 filters, kernel size 3, dilations 1/2/4/8, layer normalization, 0.02 dropout and one numerical output. Both use Adam and mean squared error loss. The parameter count is the number of learned numerical values, not a performance score.

**Loss curves.** Loss measures squared prediction error in normalized temperature units. Lower is better. Validation loss measures the same error on the later development segment. A falling training loss with a rising validation loss is a sign of possible overfitting. Initial LSTM runs use the original early-stopping settings; TCN runs use 40 epochs. Early stopping does not restore the best weights in this notebook.

**Initial R²/RMSE.** R² compares prediction errors with simply using the mean of the evaluated target values. One is perfect; zero matches that mean predictor; negative means worse. R² is not classification accuracy. Initial RMSE uses normalized target units, so it must not be described as degrees Celsius.

**Final 2017 forecasts.** Four fresh models train on all 2013–2016 samples for 47 epochs, then evaluate the last 115 records. The predictions are transformed back into degrees Celsius. Ordinary one-step forecasts receive actual observations from preceding days, including earlier 2017 observations; they are not a 115-day forecast made entirely on 31 December 2016.

**Final comparison table.** MSE averages squared differences between predicted and observed temperatures. Its unit is °C². RMSE is its square root and has units °C. Smaller is better. RMSE is a summary of error magnitude, not a guarantee that each prediction falls within that distance. Published and local values are shown separately in `comparison_with_kaggle.csv`.

**Predictions on predictions.** The final temperature-only models repeatedly feed their own forecasts into the rolling window instead of receiving new measured temperatures. Errors can accumulate and predictions can drift. This is a different, harder task from the ordinary one-step forecasts. The original recursion is preserved; it inserts target-scaled predictions into input-scaled windows without explicitly converting between the two scalers.

## What our local run found

The smallest local final RMSE belongs to **LSTM with temperature only**. See the saved comparison table for the actual measured values. A fixed architecture, one random seed and one dataset do not establish which model is always superior. The original final table also has a lower RMSE for its two-feature LSTM than for either TCN variant, even though its conclusion expresses enthusiasm for TCN.

| Variant | Published Kaggle RMSE | Local RMSE |
| --- | ---: | ---: |
| LSTM with temperature only | 1.954916 °C | 1.849131 °C |
| TCN with temperature only | 2.047225 °C | 1.906341 °C |
| LSTM with temperature and humidity | 1.850895 °C | 1.867387 °C |
| TCN with temperature and humidity | 2.036477 °C | 1.855213 °C |

The best LSTM and TCN variants have very similar errors in this local run. Small differences from one run cannot establish reliable superiority. The best input configuration also differs between the published and local runs.

## Reproduction limits preserved from the source

The original internal validation experiment fits its MinMax scalers before making the 80/20 split, so its scaling uses validation-period information. This is retained to reproduce the method. A rigorous future comparison should fit preprocessing only on the initial training segment. No 2017 rows fit the final training scalers.

The original dataset concatenation retains a duplicate date. We did not silently clean it, change the split, add features, shorten the epochs or alter model architecture. Seed 42, current TensorFlow/Keras versions, callback-list syntax, one indentation fix and local output capture are documented adaptations. Exact matching weights/metrics from an unseeded run are not guaranteed.

## How to present it

“We reproduced an existing LSTM/TCN climate forecasting experiment using its original dataset and model settings. The model reads 30 records and predicts the next temperature. We compare temperature-only and temperature-plus-humidity variants using prediction graphs, MSE and RMSE. This demonstrates sequence modeling; it is not sign-language recognition.”
