"""Verify the reproduction's metrics and generate a readable explanation/report."""
import io
import json
import os
from pathlib import Path
import re
import copy

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mplcache'))
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
from sklearn.metrics import mean_squared_error, r2_score


def main():
    out = ROOT / 'outputs'
    import nbformat
    editable = copy.deepcopy(nbformat.read(out / 'executed_notebook.ipynb', as_version=4))
    editable.cells.insert(1, nbformat.v4.new_code_cell(
        "import os\nfrom pathlib import Path\n"
        "if not Path('datasets/DelhiClimate').exists() and Path('../datasets/DelhiClimate').exists():\n    os.chdir('..')\n"
        "os.environ.setdefault('MPLCONFIGDIR', str(Path.cwd() / '.mplcache'))\n"
        "os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')\n"
        "os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')\n"
        "import tensorflow as tf\ntf.keras.utils.set_random_seed(42)"))
    for cell in editable.cells:
        if cell.cell_type == 'code':
            cell.outputs = []
            cell.execution_count = None
    nbformat.write(editable, ROOT / 'local_notebook.ipynb')
    adaptations = json.loads((out / 'adaptations.json').read_text(encoding='utf-8'))
    if not any(a.get('kind') == 'artifact' for a in adaptations):
        adaptations.append({'kind': 'artifact', 'change': 'Saved learned NumPy weights plus architecture JSON; original notebook does not save models.'})
        (out / 'adaptations.json').write_text(json.dumps(adaptations, indent=2), encoding='utf-8')
    metadata = json.loads((out / 'run_metadata.json').read_text(encoding='utf-8'))
    predictions = pd.read_csv(out / 'predictions.csv', index_col=0)
    measured = pd.read_csv(out / 'final_metrics.csv', index_col=0)
    assert metadata['data_rows'] == 1576
    assert metadata['training_rows_excluding_2017'] == 1461
    assert metadata['forecast_rows'] == 115
    assert metadata['duplicate_dates'] == 1
    assert len(metadata['experiments']) == 8
    expected_params = {'lstm_one': 115841, 'lstm_two': 116097, 'tcn_one': 87937, 'tcn_two': 88193}
    for experiment in metadata['experiments']:
        key = '_'.join(experiment['name'].split('_')[:2])
        assert experiment['parameters'] == expected_params[key], (key, experiment['parameters'])
    for loss in measured.index:
        column = loss.removesuffix('_loss')
        actual = predictions['true_temp'].to_numpy()
        predicted = predictions[column].to_numpy()
        assert np.isfinite(predicted).all()
        np.testing.assert_allclose(measured.loc[loss, 'MSE'], mean_squared_error(actual, predicted), rtol=1e-6)
        np.testing.assert_allclose(measured.loc[loss, 'RMSE'], np.sqrt(mean_squared_error(actual, predicted)), rtol=1e-6)
        measured.loc[loss, 'R2'] = r2_score(actual, predicted)
    # Published numbers come from the actual rendered notebook saved from Kaggle.
    published_html = (ROOT / 'reference' / 'original_rendered.html').read_text(encoding='utf-8')
    soup = BeautifulSoup(published_html, 'html.parser')
    table = next(t for t in soup.find_all('table') if 'MSE' in t.get_text() and 'RMSE' in t.get_text())
    original_rows = []
    for row in table.find_all('tr'):
        values = [c.get_text(strip=True) for c in row.find_all(['th', 'td'])]
        if values and values[0].endswith('_loss'):
            original_rows.append([values[0], float(values[1]), float(values[2])])
    assert len(original_rows) == 4
    published = pd.DataFrame(original_rows, columns=['model', 'MSE', 'RMSE']).set_index('model')
    comparison = pd.DataFrame(index=measured.index)
    comparison['Kaggle MSE'] = published['MSE']
    comparison['Kaggle RMSE (°C)'] = published['RMSE']
    comparison['Local MSE'] = measured['MSE']
    comparison['Local RMSE (°C)'] = measured['RMSE']
    comparison['Local R2'] = measured['R2']
    assert not comparison.isna().any().any()
    comparison.to_csv(out / 'comparison_with_kaggle.csv')
    validation_rows = [e for e in metadata['experiments'] if 'validation' in e['name']]
    pd.DataFrame(validation_rows).to_csv(out / 'validation_metrics.csv', index=False)
    recursive = {}
    for column in ['lstm_pred_on_pred', 'tcn_pred_on_pred']:
        recursive[column] = {'MSE': float(mean_squared_error(predictions.true_temp, predictions[column])),
                             'RMSE': float(np.sqrt(mean_squared_error(predictions.true_temp, predictions[column])))}
    (out / 'recursive_metrics.json').write_text(json.dumps(recursive, indent=2), encoding='utf-8')
    (out / 'verification.txt').write_text('PASS: row counts, duplicate preservation, eight trained models, original parameter counts, and metrics recomputed from saved predictions.\n', encoding='utf-8')
    notebook_url = metadata['notebook_url']
    best = comparison['Local RMSE (°C)'].idxmin().removesuffix('_loss')
    names = {'lstm_pred_one_ft': 'LSTM with temperature only', 'tcn_pred_one_ft': 'TCN with temperature only',
             'lstm_pred_two_ft': 'LSTM with temperature and humidity', 'tcn_pred_two_ft': 'TCN with temperature and humidity'}
    best_name = names[best]
    metric_table = '| Variant | Published Kaggle RMSE | Local RMSE |\n| --- | ---: | ---: |\n' + '\n'.join(
        f'| {names[index.removesuffix("_loss")]} | {row["Kaggle RMSE (°C)"]:.6f} °C | {row["Local RMSE (°C)"]:.6f} °C |'
        for index, row in comparison.iterrows())
    notes = f'''# Delhi climate notebook: results explained

Source: Ricardo Colindres, [LSTM vs TCN for Time Series Analysis Comparison]({notebook_url}), Apache 2.0.

This project reproduces the notebook's analysis and model settings. It forecasts a numerical temperature, so it is a regression experiment. Accuracy percentages used for sign classification are not appropriate here.

## What the outputs mean, in notebook order

**Dataset shape and missing-value check.** The combined files have 1,576 records and four measured variables. The null-count output is zero for every variable. The combined files have two records dated 1 January 2017; the reproduction retains both, matching the notebook. “30 days” therefore means 30 consecutive records in this code.

**Description table.** Count is the number of observations; mean is the average; std measures spread; min/max and quartiles describe the range. The pressure extremes make it unsuitable to assume every measurement is clean.

**Pair plot and correlation heatmap.** These compare variable relationships. A negative temperature/humidity correlation indicates a tendency to move in opposite directions; it does not establish causation. The forecasting models later use temperature alone, or temperature and humidity.

**Normalized temperature and humidity graphs.** Standardization puts quantities with different units on a comparable display scale. This exploratory StandardScaler does not train the forecasting models. Their preprocessing separately uses MinMaxScaler.

**Yearly curves and box plots.** Curves reveal repeating annual patterns. Box plots summarize each year/month's spread, median and unusually distant observations.

**Seasonal decomposition.** The moving-average and polynomial approaches separate temperature into a longer-term trend, recurring monthly pattern and residual variation. Those components help explain the data, but they are not the inputs fed into the LSTM/TCN training cells. The residual includes whatever these simple trend/seasonal approximations do not explain; a plot alone does not prove it is entirely random.

**Autocorrelation.** This plots the relationship between a temperature value and earlier values at different lags. It helps illustrate temporal dependence and recurring patterns.

**Initial train/validation experiments.** A sample consists of 30 consecutive records used to predict the next temperature. Data from 2017 are excluded. The first 80% of the resulting samples train the model, while the last 20% appear as `X_test`/`y_test` in code and also supply validation losses. Treat this initial segment as validation/model development because the notebook uses it during training.

**Model summaries.** LSTM has stacked 64-unit and 128-unit recurrent layers, then one numerical output. TCN has 64 filters, kernel size 3, dilations 1/2/4/8, layer normalization, 0.02 dropout and one numerical output. Both use Adam and mean squared error loss. The parameter count is the number of learned numerical values, not a performance score.

**Loss curves.** Loss measures squared prediction error in normalized temperature units. Lower is better. Validation loss measures the same error on the later development segment. A falling training loss with a rising validation loss is a sign of possible overfitting. Initial LSTM runs use the original early-stopping settings; TCN runs use 40 epochs. Early stopping does not restore the best weights in this notebook.

**Initial R²/RMSE.** R² compares prediction errors with simply using the mean of the evaluated target values. One is perfect; zero matches that mean predictor; negative means worse. R² is not classification accuracy. Initial RMSE uses normalized target units, so it must not be described as degrees Celsius.

**Final 2017 forecasts.** Four fresh models train on all 2013–2016 samples for 47 epochs, then evaluate the last 115 records. The predictions are transformed back into degrees Celsius. Ordinary one-step forecasts receive actual observations from preceding days, including earlier 2017 observations; they are not a 115-day forecast made entirely on 31 December 2016.

**Final comparison table.** MSE averages squared differences between predicted and observed temperatures. Its unit is °C². RMSE is its square root and has units °C. Smaller is better. RMSE is a summary of error magnitude, not a guarantee that each prediction falls within that distance. Published and local values are shown separately in `comparison_with_kaggle.csv`.

**Predictions on predictions.** The final temperature-only models repeatedly feed their own forecasts into the rolling window instead of receiving new measured temperatures. Errors can accumulate and predictions can drift. This is a different, harder task from the ordinary one-step forecasts. The original recursion is preserved; it inserts target-scaled predictions into input-scaled windows without explicitly converting between the two scalers.

## What our local run found

The smallest local final RMSE belongs to **{best_name}**. See the saved comparison table for the actual measured values. A fixed architecture, one random seed and one dataset do not establish which model is always superior. The original final table also has a lower RMSE for its two-feature LSTM than for either TCN variant, even though its conclusion expresses enthusiasm for TCN.

{metric_table}

The best LSTM and TCN variants have very similar errors in this local run. Small differences from one run cannot establish reliable superiority. The best input configuration also differs between the published and local runs.

## Reproduction limits preserved from the source

The original internal validation experiment fits its MinMax scalers before making the 80/20 split, so its scaling uses validation-period information. This is retained to reproduce the method. A rigorous future comparison should fit preprocessing only on the initial training segment. No 2017 rows fit the final training scalers.

The original dataset concatenation retains a duplicate date. We did not silently clean it, change the split, add features, shorten the epochs or alter model architecture. Seed 42, current TensorFlow/Keras versions, callback-list syntax, one indentation fix and local output capture are documented adaptations. Exact matching weights/metrics from an unseeded run are not guaranteed.

## How to present it

“We reproduced an existing LSTM/TCN climate forecasting experiment using its original dataset and model settings. The model reads 30 records and predicts the next temperature. We compare temperature-only and temperature-plus-humidity variants using prediction graphs, MSE and RMSE. This demonstrates sequence modeling; it is not sign-language recognition.”
'''
    (ROOT / 'RESULTS_EXPLAINED.md').write_text(notes, encoding='utf-8')
    cards = []
    descriptions = {
        8: 'Pair plot: relationships between all measured variables.',
        9: 'Correlation heatmap: strength and direction of linear relationships.',
        12: 'Temperature and humidity standardized to a common display scale.',
        14: 'Annual standardized patterns for the final two complete years.',
        15: 'Temperature patterns across complete years.',
        16: 'Temperature distribution by year.', 17: 'Humidity distribution by year.',
        18: 'Temperature distribution by month.',
        21: 'Moving-average decomposition into trend, seasonal pattern and residual.',
        26: 'Polynomial decomposition: another exploratory estimate of trend and seasonality.',
        27: 'Autocorrelation: temperature relationships across time lags.',
        36: 'Initial chronological split for temperature and humidity inputs.',
        39: 'Initial LSTM with two features: normalized loss and prediction curves.',
        41: 'Initial chronological split for temperature-only input.',
        44: 'Initial LSTM with one feature: normalized loss and prediction curves.',
        52: 'Initial split for temperature-only TCN.',
        55: 'Initial TCN with one feature: normalized loss and prediction curves.',
        57: 'Initial split for temperature-plus-humidity TCN.',
        60: 'Initial TCN with two features: normalized loss and prediction curves.',
        64: 'First part of each year compared with 2017.',
        76: 'Final one-step forecasts using temperature and humidity, in degrees Celsius.',
        86: 'Final one-step forecasts using temperature alone, in degrees Celsius.',
        93: 'Recursive forecasts: each new prediction becomes part of the next input window.'}
    for figure in metadata['figures']:
        description = descriptions.get(figure['cell'], 'Figure reproduced from the original notebook.')
        cards.append(f'<figure><img src="{figure["file"]}" alt="Original notebook cell {figure["cell"]}"><figcaption>Cell {figure["cell"]}: {description}</figcaption></figure>')
    html = f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Kaggle LSTM vs TCN reproduction</title>
<style>body{{font:17px system-ui;background:#f4f7fb;color:#192b40;max-width:1120px;margin:40px auto;padding:22px;line-height:1.6}}h1{{font-size:38px;line-height:1.2}}.notice{{background:#fff0cc;padding:18px;border-radius:10px}}.tablewrap{{overflow:auto}}table{{border-collapse:collapse;width:100%;font-size:15px}}td,th{{padding:12px;border-bottom:1px solid #ccd5e0;text-align:left}}figure{{margin:30px 0;background:white;padding:16px;border-radius:10px}}img{{max-width:100%}}figcaption{{padding:12px}}a{{color:#1265a8}}</style></head><body>
<p>REPRODUCTION OF RICARDO COLINDRES'S KAGGLE NOTEBOOK</p><h1>LSTM vs TCN: Delhi temperature forecasting</h1><p><a href="{notebook_url}">Original Kaggle notebook</a> · <a href="notebook.html">Complete locally executed notebook</a></p>
<div class="notice">Forecasting experiment, not sign-language recognition. Both the published numbers and our newly trained local results are shown. Lower RMSE is better; R² is not accuracy.</div>
<h2>What was trained</h2><p>30 consecutive climate records predict the next temperature. Four model variants use either temperature alone or temperature plus humidity. The original notebook also trains four models during its initial validation stage.</p>
<h2>Final one-step forecasts: published vs local</h2><div class="tablewrap">{comparison.round(6).to_html()}</div>
<p>All final RMSE values use degrees Celsius. Best local variant: <strong>{best_name}</strong>. Model initialization and current library versions can change the ranking and numerical results.</p>
<h2>Initial validation stage</h2><p>These RMSE values use normalized target units, not degrees Celsius.</p><div class="tablewrap">{pd.DataFrame(validation_rows)[['model','inputs','epochs_completed','parameters','r2_scaled','rmse_scaled']].round(6).to_html(index=False)}</div>
<h2>How to read the graphs</h2><p>Loss curves show learning error over epochs. Forecast graphs compare observed temperatures with predictions. Seasonal plots show recurring patterns. The final recursive plot feeds predictions back into the model, so errors can accumulate.</p>
<h2>Reproduced notebook figures, in original order</h2>{''.join(cards)}
<h2>Method limits</h2><p>The original initial scalers use all 2013–2016 rows before the 80/20 split, and the combined files retain two entries for 1 January 2017. Both behaviors are preserved. The ordinary forecasts use actual preceding observations; only the recursive experiment repeatedly uses model predictions. See RESULTS_EXPLAINED.md for the full explanation and adaptations.json for local compatibility changes.</p>
<p>Attribution: Ricardo Colindres, original notebook, Apache 2.0. Dataset: Sumanth Rao's Daily Climate time series data on Kaggle. Checks passed for source shapes, original model parameter counts and recomputed metrics.</p></body></html>'''
    (out / 'report.html').write_text(html, encoding='utf-8')
    print(comparison.to_string())
    print('PASS: verified shapes, model sizes and independently recomputed prediction metrics.')


if __name__ == '__main__':
    main()
