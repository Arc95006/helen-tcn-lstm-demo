"""Execute Ricardo Colindres's Apache-2.0 Kaggle notebook, preserving cell order.

Notebook: https://www.kaggle.com/code/ricardocolindres/lstm-vs-tcn-for-time-series-analysis-comparison
Only local execution/formatting adaptations are applied; see adaptations.json.
"""
import ast
import base64
import contextlib
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import time
import traceback
import zipfile
import faulthandler

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mplcache'))
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
os.environ.setdefault('OMP_NUM_THREADS', '2')
temp_directory = ROOT / '.tmp'
temp_directory.mkdir(exist_ok=True)
os.environ['TMP'] = str(temp_directory)
os.environ['TEMP'] = str(temp_directory)
faulthandler.enable()
faulthandler.dump_traceback_later(300, repeat=True)

import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import nbformat
from nbconvert import HTMLExporter
from IPython.core.interactiveshell import InteractiveShell
import numpy as np
import tensorflow as tf


class Tee(io.StringIO):
    def write(self, text):
        sys.__stdout__.write(text)
        sys.__stdout__.flush()
        return super().write(text)


def main():
    reference = ROOT / 'reference'
    original = json.loads((reference / 'original_kaggle.ipynb').read_text(encoding='utf-8'))
    data = ROOT / 'datasets' / 'DelhiClimate'
    data.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(reference / 'daily_climate.zip') as z:
        for filename in ['DailyDelhiClimateTrain.csv', 'DailyDelhiClimateTest.csv']:
            (data / filename).write_bytes(z.read(filename))
    output = ROOT / 'outputs'
    figures = output / 'figures'
    models = output / 'models'
    figures.mkdir(parents=True, exist_ok=True)
    models.mkdir(parents=True, exist_ok=True)
    tf.config.threading.set_intra_op_parallelism_threads(2)
    tf.config.threading.set_inter_op_parallelism_threads(2)
    tf.keras.utils.set_random_seed(42)
    shell = InteractiveShell.instance()
    namespace = {'__name__': '__main__'}
    executed = nbformat.v4.new_notebook()
    executed.cells.append(nbformat.v4.new_markdown_cell(
        '# Local reproduction of LSTM vs TCN for Time Series Analysis Comparison\n'
        'Original author: Ricardo Colindres. [Original notebook](https://www.kaggle.com/code/ricardocolindres/lstm-vs-tcn-for-time-series-analysis-comparison), Apache 2.0.\n\n'
        'All outputs below were generated locally. Model settings, original cell order, datasets, splitting and scaling logic are retained. '
        'Local changes: seed 42, CPU thread limits, noninteractive figure capture, callbacks passed as a list, and one leading-space typo fixed. '
        'Modern TensorFlow/Keras versions can produce different model results and display formatting. '
        'The original initial split fits scalers before its internal validation split; this behavior is reproduced and documented, not silently changed.'))
    executed.metadata = {'kernelspec': {'name': 'python3', 'display_name': 'Python 3 (local climate)', 'language': 'python'}}
    adaptations = [
        {'kind': 'execution', 'change': 'Set random seed 42; original notebook has no fixed seed.'},
        {'kind': 'execution', 'change': 'CPU thread limits and local figure/artifact capture.'},
        {'kind': 'artifact', 'change': 'Save learned weights as NumPy arrays and model architecture as JSON; original notebook does not save model files.'},
        {'cell': 38, 'change': 'callbacks=early_stop becomes callbacks=[early_stop] for current Keras.'},
        {'cell': 43, 'change': 'callbacks=early_stop becomes callbacks=[early_stop] for current Keras.'},
        {'cell': 78, 'change': 'Remove one accidental leading space before the top-level colums assignment.'},
    ]
    (output / 'adaptations.json').write_text(json.dumps(adaptations, indent=2), encoding='utf-8')
    experiment_records = []
    validations = {39: ('LSTM', 'temperature + humidity'), 44: ('LSTM', 'temperature'),
                   55: ('TCN', 'temperature'), 60: ('TCN', 'temperature + humidity')}
    trained_cells = {38: ('lstm_two_feature_validation', 'lstm_model_many'),
                     43: ('lstm_one_feature_validation', 'lstm_model_one'),
                     54: ('tcn_one_feature_validation', 'model'), 59: ('tcn_two_feature_validation', 'model'),
                     70: ('lstm_two_feature_final', 'lstm_model'), 72: ('tcn_two_feature_final', 'tcn_model'),
                     80: ('lstm_one_feature_final', 'lstm_model'), 82: ('tcn_one_feature_final', 'tcn_model')}
    durations = {}
    figure_manifest = []
    count = 0
    started = time.perf_counter()
    for index, original_cell in enumerate(original['cells']):
        source = original_cell['source']
        if isinstance(source, list):
            source = ''.join(source)
        if original_cell['cell_type'] != 'code':
            executed.cells.append(nbformat.v4.new_markdown_cell(source))
            continue
        count += 1
        if index in [38, 43]:
            source = source.replace('callbacks=early_stop', 'callbacks=[early_stop]')
        if index == 78:
            source = source.lstrip(' ')
        local_cell = nbformat.v4.new_code_cell(source)
        local_cell.execution_count = count
        local_cell.metadata['original_cell_index'] = index
        executed.cells.append(local_cell)
        print(f'Executing original cell {index} ({count}): {source.splitlines()[0][:100]}', flush=True)

        def capture_figures(*args, **kwargs):
            for number in plt.get_fignums():
                fig = plt.figure(number)
                filename = f'{len(figure_manifest)+1:02d}_cell_{index}.png'
                fig.savefig(figures / filename, dpi=110, bbox_inches='tight')
                buffer = io.BytesIO()
                fig.savefig(buffer, format='png', dpi=110, bbox_inches='tight')
                local_cell.outputs.append(nbformat.v4.new_output('display_data', data={
                    'image/png': base64.b64encode(buffer.getvalue()).decode('ascii'),
                    'text/plain': f'Figure from original cell {index}'}))
                figure_manifest.append({'cell': index, 'file': 'figures/' + filename})
                plt.close(fig)
        plt.show = capture_figures
        stream = Tee()
        cell_started = time.perf_counter()
        try:
            tree = ast.parse(source, filename=f'original_cell_{index}')
            last = None
            if tree.body and isinstance(tree.body[-1], ast.Expr):
                last = tree.body.pop()
            with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
                exec(compile(tree, f'original_cell_{index}', 'exec'), namespace)
                if last is not None:
                    value = eval(compile(ast.Expression(last.value), f'original_cell_{index}', 'eval'), namespace)
                    if value is not None:
                        display_data, display_metadata = shell.display_formatter.format(value)
                        if display_data:
                            local_cell.outputs.append(nbformat.v4.new_output('execute_result',
                                data=display_data, metadata=display_metadata, execution_count=count))
                capture_figures()
            if stream.getvalue():
                local_cell.outputs.insert(0, nbformat.v4.new_output('stream', name='stdout', text=stream.getvalue()))
        except Exception as error:
            local_cell.outputs.append(nbformat.v4.new_output('error', ename=type(error).__name__,
                                     evalue=str(error), traceback=traceback.format_exc().splitlines()))
            nbformat.write(executed, output / 'executed_notebook.ipynb')
            raise
        durations[index] = time.perf_counter() - cell_started
        if index in trained_cells:
            label, variable = trained_cells[index]
            model = namespace[variable]
            # Artifact-only addition: NumPy weights avoid a local .keras/HDF save stall.
            np.savez_compressed(models / f'{label}_weights.npz', **{
                f'weight_{i}': weight for i, weight in enumerate(model.get_weights())})
            (models / f'{label}_architecture.json').write_text(model.to_json(), encoding='utf-8')
            (output / f'{label}_history.json').write_text(json.dumps(namespace['results'].history, indent=2), encoding='utf-8')
            experiment_records.append({'name': label, 'original_cell': index, 'parameters': model.count_params(),
                                       'epochs_completed': len(namespace['results'].history['loss']), 'fit_cell_seconds': durations[index]})
        if index in validations:
            from sklearn.metrics import mean_squared_error, r2_score
            name, inputs = validations[index]
            predicted, actual = namespace['y_pred'], namespace['y_test']
            experiment_records[-1].update(model=name, inputs=inputs, r2_scaled=float(r2_score(actual, predicted)),
                                          rmse_scaled=float(np.sqrt(mean_squared_error(actual, predicted))))
        nbformat.write(executed, output / 'executed_notebook.ipynb')
    assessment = namespace['df_assesment']
    assessment.to_csv(output / 'predictions.csv')
    namespace['df_metrics'].to_csv(output / 'final_metrics.csv')
    metadata = {'notebook_url': 'https://www.kaggle.com/code/ricardocolindres/lstm-vs-tcn-for-time-series-analysis-comparison',
                'author': 'Ricardo Colindres', 'seed': 42, 'tensorflow': tf.__version__,
                'total_seconds': time.perf_counter()-started, 'data_rows': len(namespace['df']),
                'duplicate_dates': int(namespace['df'].index.duplicated().sum()),
                'training_rows_excluding_2017': int((namespace['df'].index.year != 2017).sum()),
                'forecast_rows': len(assessment), 'experiments': experiment_records,
                'figures': figure_manifest,
                'data_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in data.glob('*.csv')}}
    (output / 'run_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    html, _ = HTMLExporter().from_notebook_node(executed)
    (output / 'notebook.html').write_text(html, encoding='utf-8')
    editable = copy.deepcopy(executed)
    editable.cells.insert(1, nbformat.v4.new_code_cell(
        "import os\nfrom pathlib import Path\n"
        "if not Path('datasets/DelhiClimate').exists() and Path('../datasets/DelhiClimate').exists():\n    os.chdir('..')\n"
        "os.environ.setdefault('MPLCONFIGDIR', str(Path.cwd() / '.mplcache'))\n"
        "os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')\n"
        "os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')\n"
        "import tensorflow as tf\ntf.keras.utils.set_random_seed(42)"))
    for cell in editable.cells:
        if cell.cell_type == 'code':
            cell.outputs = []
            cell.execution_count = None
    nbformat.write(editable, ROOT / 'local_notebook.ipynb')
    faulthandler.cancel_dump_traceback_later()
    print('Completed all original notebook cells. Saved notebook, plots, models and metrics.', flush=True)


if __name__ == '__main__':
    main()
