"""Load one of the eight saved models without retraining."""
from pathlib import Path
import numpy as np
from tensorflow.keras.models import model_from_json
from tcn import TCN


def load_saved_model(name):
    directory = Path(__file__).resolve().parent / 'outputs' / 'models'
    model = model_from_json((directory / f'{name}_architecture.json').read_text(encoding='utf-8'),
                            custom_objects={'TCN': TCN})
    with np.load(directory / f'{name}_weights.npz', allow_pickle=False) as weights:
        model.set_weights([weights[f'weight_{i}'] for i in range(len(weights.files))])
    return model
