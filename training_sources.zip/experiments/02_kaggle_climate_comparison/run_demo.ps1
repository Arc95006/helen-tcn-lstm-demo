$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$taskPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $taskPython reproduce.py
if ($LASTEXITCODE -ne 0) { throw 'Notebook reproduction failed. Partial outputs are preserved.' }
& $taskPython explain_results.py
if ($LASTEXITCODE -ne 0) { throw 'Result verification failed.' }
Start-Process -FilePath (Join-Path $PSScriptRoot 'outputs\report.html')
